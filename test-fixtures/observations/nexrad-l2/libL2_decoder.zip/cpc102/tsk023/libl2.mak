# RCS info
# $Author: jeffs $
# $Locker:  $
# $Date: 2015/03/11 19:42:30 $
# $Id: libl2.mak,v 1.4 2015/03/11 19:42:30 jeffs Exp $
# $Revision: 1.4 $
# $State: Exp $

include $(MAKEINC)/make.common
include $(MAKEINC)/make.$(ARCH)


LOCAL_INCLUDES = 

# You can also include architecture specific includes, if needed, by
# defining $(ARCH)_INC and then adding it to the list of ALL_INCLUDES.

LOCAL_DEFINES = -DLIBL2

# You can also include architecture specific defines, if needed, by
# defining $(ARCH)_DEF and then adding it to the list of ALL_DEFINES.

ALL_INCLUDES = $(STD_INCLUDES) $(LOCALTOP_INCLUDES) $(TOP_INCLUDES) \
			 $(LOCAL_INCLUDES) $(SYS_INCLUDES) $(X_INCLUDES)

# This is a list of all defines.
ALL_DEFINES = $(STD_DEFINES) $(OS_DEFINES) $(LOCAL_DEFINES) $(SYS_DEFINES) $(X_DEFINES)

CCFLAGS = $(COMMON_CCFLAGS) $(ALL_INCLUDES) $(ALL_DEFINES)
DEBUGCCFLAGS = $(COMMON_DEBUGCCFLAGS) $(ALL_INCLUDES) $(ALL_DEFINES)
DEPENDFLAGS =
SHRDLIBLD_SEARCHLIBS= $(X_LIBPATH) -lm -lz -lbz2

clean::
	$(RM) ./orpgumc_rda.c

orpgumc_rda.c:
	$(_V_LN)$(LN_S) ../../cpc101/lib003/$@ .

LIB_CSRCS	=	libl2.c \
			orpgumc_rda.c

LIB_TARGET = l2

DEPENDFILE = ./depend.lib$(LIB_TARGET).$(ARCH)

include $(MAKEINC)/make.cflib

-include $(DEPENDFILE)

