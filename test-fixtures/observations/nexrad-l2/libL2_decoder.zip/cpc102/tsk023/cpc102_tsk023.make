# RCS info
# $Author: steves $
# $Locker:  $
# $Date: 2016/02/25 16:31:41 $
# $Id: cpc102_tsk023.make,v 1.8 2016/02/25 16:31:41 steves Exp $
# $Revision: 1.8 $
# $State: Exp $

include $(MAKEINC)/make.common
include $(MAKEINC)/make.$(ARCH)

BINMAKEFILES = parse_ldm_file.mak validate_ldm_file.mak testlibl2.mak metadump.mak
LIBMAKEFILES = libl2.mak libl2_static.mak

include $(MAKEINC)/make.parent_bin
include $(MAKEINC)/make.parent_lib

