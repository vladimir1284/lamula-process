#include <stdlib.h>
#include <stdio.h>
#include <libl2.h>

/* Global Variables. */
static char *Filename = NULL;
static int Rda_status = 0;
static int Rda_pmd = 0;
static int Rda_vcp = 0;
static int Rda_adapt = 0;
static int Rda_prf_tables = 0;
static int Rda_clutter_map = 0;
static int Rda_map_segment = 0;
static int Debug = 0;


/* Function Prototypes. */
static int Read_options( int argc, char *argv[] );
static void Print_usage( int argc, char *argv[] );

/*\//////////////////////////////////////////////////////////////////////

   Description:
      metadump program ... dumps metadata from a user supplied Level 2 
      file.

//////////////////////////////////////////////////////////////////////\*/
int main( int argc, char *argv[] ){

   int i, code = 0;

   /* Read command line options. */
   if( Read_options( argc, argv ) < 0 )
      return -1;

   if( Debug )
      libL2_debug_on();

   /* Read user supplied file. */
   if( (code = libL2_read( Filename )) != LIBL2_NO_ERROR ){

      fprintf( stderr, "Error Reading File %s: Error: %d\n", 
               Filename, code );
      return code;

   }

   printf( "VOLUME DATETIME: %s  %s\n", libL2_date(), libL2_time() );
   
   /* Do you want to dump RDA Status Message(s). */
   if( Rda_status )
      libL2_print_rda_status_msgs();

   /* Do you want to dump RDA Performance/Maintenance Data Message. */
   if( Rda_pmd )
      libL2_print_rda_pmd();

   /* Do you want to dump RDA VCP Message. */
   if( Rda_vcp )
      libL2_print_rda_VCP();

   /* Do you want to dump RDA Adaptation Data Message. */
   if( Rda_adapt )
      libL2_print_rda_adapt();

   /* Do you want to dump RDA PRF Tables Message. */
   if( Rda_prf_tables )
      libL2_print_rda_prf_tables();

   /* Do you want to dump the RDA Clutter Map Message. */
   if( (Rda_clutter_map) && (Rda_map_segment > 0) ){

      /* There are 360 radials in each segmap map.  The radials 
         are numbered 1-360. */
      for( i = 1; i <= 360; i++ )
         libL2_print_rda_clutter_map( Rda_map_segment, i );

   }

   return EXIT_SUCCESS;

}

/*\////////////////////////////////////////////////////////////////////////

   Description:
      Reads command line arguments.

   Input:        
      argc - Number of command line arguments.
      argv - Command line arguments.

   Output:       
      Usage message

   Returns:      
      0 on success or -1 on failure

   Notes: Currently only accepts a LevelII file name.
      
////////////////////////////////////////////////////////////////////////\*/
static int Read_options( int argc, char *argv[] ){

   int len = 0, c = 0;
   extern char *optarg; 

   while ((c = getopt(argc, argv, "advpc:sth")) != -1){

      switch (c) {

         case 'a':
            Rda_adapt = 1;
            break;

         case 'd':
            Debug = 1;
            break;

         case 'v': 
            Rda_vcp = 1;
            break;

         case 'p': 
            Rda_pmd = 1;
            break;

         case 's': 
            Rda_status = 1;
            break;

         case 'c': 
            Rda_clutter_map = 1;
            Rda_map_segment = atoi( optarg );
            break;

	 case 't':
	    Rda_prf_tables = 1;
	    break;

         case 'h':
         default:
            Print_usage( argc, argv );
            return -1;

      }

   }

   /* Make sure a input file has been specified. */  
   if( argc < 2 ){

      fprintf( stderr, "Must supply an input file!" );
      Print_usage(argc, argv);
      return -1;

   }

   /* Get the filename length so space can be allocated. */
   len = strlen( argv[optind] );
   if( len <= 0 ){

      fprintf( stderr, "Invalid Filename Len: %d\n", len );
      return -1;

   }

   /* Allocate space. */
   Filename = calloc( 1, len+1 );
   strcpy( Filename, argv[optind] );

   /* If all meta data flags are zero, set them all to 1. */
   if( (Rda_status == 0) 
            && 
       (Rda_pmd == 0)
            && 
       (Rda_adapt == 0)
            && 
       (Rda_clutter_map == 0) 
            &&
       (Rda_prf_tables == 0)
            &&
       (Rda_vcp == 0) ){

      Rda_status = 1;
      Rda_pmd = 1;
      Rda_adapt = 1;
      Rda_vcp = 1;
      Rda_clutter_map = 1;
      Rda_prf_tables = 1;
      Rda_map_segment = 1;

   }
                      
   return 0;

/* End of Read_options(). */
}

/*////////////////////////////////////////////////////////////////////

   Description:
      Print usage messages. 

///////////////////////////////////////////////////////////////////\*/
static void Print_usage( int argc, char *argv[] ){

    fprintf( stderr, "Usage: %s (options) <filename>\n", argv[0] );
    fprintf( stderr, "\toptions:\n" );
    fprintf( stderr, "\t-v  Dump RDA VCP Data\n" );
    fprintf( stderr, "\t-s  Dump RDA Status Message(s)\n" );
    fprintf( stderr, "\t-p  Dump RDA Performance/Maintenance Data\n" );
    fprintf( stderr, "\t-a  Dump RDA Adaptation Data\n" );
    fprintf( stderr, "\t-c  Dump RDA Clutter Map Data\n" );
    fprintf( stderr, "\t-t  Dump RDA PRF Table Data\n" );
    fprintf( stderr, "\t-d  Turn on Debugging\n" );
    fprintf( stderr, "\t-h  Help\n" );
    fprintf( stderr, "\n\tNote: If -v, -s, -a, -t, -c and -p not specified\n" );
    fprintf( stderr, "\t      all the data is dumped.\n" );

/* End of Print_usage(). */
}
